<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sign In – RefinePoint</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%234f46e5'/><text y='22' x='7' font-size='18' font-weight='900' fill='white' font-family='sans-serif'>R</text></svg>" />
  <link rel="stylesheet" href="${url.resourcesPath}/css/login.css" />
</head>
<body>

  <div class="rp-page">

    <!-- ── Left panel: branding ── -->
    <div class="rp-left">
      <div class="rp-left-inner">

        <div class="rp-brand">
          <div class="rp-logo">R</div>
          <div>
            <div class="rp-app-name">RefinePoint</div>
            <div class="rp-app-tagline">by Ryfn Flow</div>
          </div>
        </div>

        <div class="rp-left-body">
          <h2 class="rp-left-heading">Enterprise Reconciliation,<br/>simplified.</h2>
          <p class="rp-left-sub">Match, validate and close your books faster with intelligent reconciliation workflows.</p>

          <ul class="rp-features">
            <li>
              <span class="rp-feat-icon">⚡</span>
              <div>
                <strong>Automated matching</strong>
                <p>FOB, Cash, Vendor, GST — rule-based and tolerance-aware.</p>
              </div>
            </li>
            <li>
              <span class="rp-feat-icon">🔗</span>
              <div>
                <strong>Any data source</strong>
                <p>Connect PostgreSQL, Airtable, REST APIs or upload CSV/Excel.</p>
              </div>
            </li>
            <li>
              <span class="rp-feat-icon">📊</span>
              <div>
                <strong>Real-time exceptions</strong>
                <p>Instant visibility into breaks, variances and pending approvals.</p>
              </div>
            </li>
          </ul>
        </div>

        <p class="rp-left-footer">© 2026 Ryfn Flow · refinepoint.com</p>
      </div>
    </div>

    <!-- ── Right panel: login form ── -->
    <div class="rp-right">
      <div class="rp-card">

        <h1 class="rp-heading">Sign in</h1>
        <p class="rp-sub">Enter your credentials to access the platform.</p>

        <!-- Flash message -->
        <#if message?has_content>
          <div class="rp-alert rp-alert-${message.type}">
            <span class="rp-alert-icon">
              <#if message.type = "error">✕<#elseif message.type = "success">✓<#else>!</#if>
            </span>
            <span>${message.summary?no_esc}</span>
          </div>
        </#if>

        <form id="kc-form-login" action="${url.loginAction}" method="post">

          <!-- Username / Email -->
          <div class="rp-field <#if messagesPerField.existsError('username','password')>rp-field-error</#if>">
            <label class="rp-label" for="username">
              <#if !realm.loginWithEmailAllowed>Username
              <#elseif !realm.registrationEmailAsUsername>Username or email
              <#else>Email address</#if>
            </label>
            <input
              id="username"
              class="rp-input"
              name="username"
              type="text"
              value="${(login.username!'')?html}"
              autocomplete="username"
              autocapitalize="off"
              autofocus
              <#if usernameEditDisabled??>disabled</#if>
            />
            <#if messagesPerField.existsError('username')>
              <span class="rp-field-msg">${messagesPerField.get('username')?no_esc}</span>
            </#if>
          </div>

          <!-- Password -->
          <div class="rp-field <#if messagesPerField.existsError('password')>rp-field-error</#if>">
            <div class="rp-label-row">
              <label class="rp-label" for="password">Password</label>
              <#if realm.resetPasswordAllowed>
                <a class="rp-forgot" href="${url.loginResetCredentialsUrl}">Forgot password?</a>
              </#if>
            </div>
            <div class="rp-input-wrap">
              <input id="password" class="rp-input" name="password" type="password" autocomplete="current-password" />
              <button type="button" class="rp-eye-btn" onclick="togglePwd()" aria-label="Show password">
                <svg id="eye-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                  fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                </svg>
              </button>
            </div>
            <#if messagesPerField.existsError('password')>
              <span class="rp-field-msg">${messagesPerField.get('password')?no_esc}</span>
            </#if>
          </div>

          <!-- Remember me -->
          <#if realm.rememberMe && !usernameEditDisabled??>
            <label class="rp-checkbox-label">
              <input type="checkbox" name="rememberMe" <#if login.rememberMe??>checked</#if> />
              <span>Remember me</span>
            </label>
          </#if>

          <input type="hidden" name="credentialId" value="${(auth.selectedCredential!'')?html}" />
          <button class="rp-btn-primary" type="submit">Sign in</button>

        </form>

        <!-- Social providers -->
        <#if social?? && social.providers?has_content>
          <div class="rp-divider"><span>or continue with</span></div>
          <div class="rp-social-list">
            <#list social.providers as p>
              <a class="rp-social-btn" href="${p.loginUrl}">
                <#if p.iconClasses?has_content>
                  <i class="${p.iconClasses}" aria-hidden="true"></i>
                <#else>
                  <span class="rp-social-initial">${p.displayName[0]}</span>
                </#if>
                ${p.displayName}
              </a>
            </#list>
          </div>
        </#if>

        <!-- Register link -->
        <#if realm.password && realm.registrationAllowed && !registrationDisabled??>
          <p class="rp-register">
            Don't have an account? <a href="${url.registrationUrl}">Create account</a>
          </p>
        </#if>

      </div>
    </div>

  </div>

  <script>
    function togglePwd() {
      var input = document.getElementById('password');
      var icon  = document.getElementById('eye-icon');
      if (input.type === 'password') {
        input.type = 'text';
        icon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>';
      } else {
        input.type = 'password';
        icon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
      }
    }
  </script>

</body>
</html>
